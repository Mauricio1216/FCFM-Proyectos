<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['IDUsuario'])) {
    header("Location: login.php");
    exit;
}

$usuarioID = $_SESSION['IDUsuario'];

// Obtener todos los chats donde participa el usuario
$stmt = $pdo->prepare("
    SELECT c.IDChat, 
           u.Nombre AS NombreOtroUsuario
    FROM chats c
    JOIN usuarios u ON (u.IDUsuario = CASE 
        WHEN c.Usuario1 = ? THEN c.Usuario2
        ELSE c.Usuario1
    END)
    WHERE c.Usuario1 = ? OR c.Usuario2 = ?
");
$stmt->execute([$usuarioID, $usuarioID, $usuarioID]);
$chats = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bandeja de Mensajes</title>
    <link rel="stylesheet" href="mensajeria.css">
</head>
<body>
    <header>
        <div class="container">
            <a href="Landing_page.php"><h1 class="logo">Mi Tiendita Online <img src="imgs/logo.png" width="61" height="55"></h1></a>
            <div class="search-bar">
                <form action="Busqueda.php" method="GET">
                    <input type="text" name="q" placeholder="Buscar productos, marcas o categorías" required>
                    <button type="submit">Buscar</button>
                </form>
            </div>

            <nav>
                <ul>
                        <?php if (isset($_SESSION['Username'])): ?>
                            <li><a href="ver_lista.php">Listas</a></li>
                        <?php endif; ?>
                    <!--<li><a href="perfil.php">Perfil</a></li>-->
                    <div class="welcome-user">
                        <?php if (isset($_SESSION['Username'])): ?>
                            <li><a href="perfil.php">Perfil: <?php echo htmlspecialchars($_SESSION['Username']); ?> </a></li>
                        <?php endif; ?>
                    </div>
                    <?php if (isset($_SESSION['Username'])): ?>
                        <li><a href="ver_carrito.php">Carrito</a></li>
                    <?php endif; ?>
                    <li><a href="mensajes.php">Mensajes</a></li>
                    <li><a href="Login.php">Cerrar Sesión</a></li>
                    
                </ul>
            </nav>
            
        </div>
    </header>

    <main>
        <h1>Mis conversaciones</h1>
        <ul>
            <?php if (empty($chats)): ?>
                <p>No tienes conversaciones.</p>
            <?php else: ?>
                <?php foreach ($chats as $chat): ?>
                <div class="bandeja">
                    <div class="mensaje">
                    <li>
                    <a href="chat.php?chat_id=<?= $chat['IDChat'] ?>">
                        <div class="remitente">Chat con <?= htmlspecialchars($chat['NombreOtroUsuario']) ?></div>
                    </a>
                    </li>
                    </div>    
                </div>     
                <?php endforeach; ?>
            <?php endif; ?>
        </ul>
    </main>
</body>
</html>
