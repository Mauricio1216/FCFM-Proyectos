<?php
session_start();
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    try {
        // Verificar que exista un usuario con ese email
        $stmt = $pdo->prepare("SELECT IDUsuario, Username, Contra, Rol FROM usuarios WHERE Email = ?");
        $stmt->execute([$email]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($usuario && password_verify($password, $usuario['Contra'])) {
            // Datos de la sesión
            $_SESSION['IDUsuario'] = $usuario['IDUsuario'];
            $_SESSION['Username'] = $usuario['Username'];
            $_SESSION['Rol'] = $usuario['Rol'];

            // Verificar a donde se dirige el usuario segun su Rol
            if ($usuario['Rol'] == 1) {
                header("Location: Landing_page.php"); // Vendedor
            } else if ($usuario['Rol'] == 2) {
                header("Location: Landing_Admin.php");
            } 
            else {
                header("Location: Land_page_comp.php"); // Comprador
            }
            exit();
        } else {
            echo "<script>alert('Correo o contraseña incorrectos.'); window.location.href = 'Login.php';</script>"; // cambiar/mejorar 
        }
    } catch (PDOException $e) {
        echo "Error al iniciar sesión: " . $e->getMessage();
    }
}
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio de sesión</title>
    <link rel="stylesheet" href="InicioSesionEstilos.css"> 
</head>
<body>
    <!-- Header -->
    <header>
        <div class="container">
            <a href="Landing_page.php"><h1 class="logo">Mi Tiendita Online <img src="imgs/logo.png" width="61" height="55"></h1></a>
            <nav>
                <ul>
                    <li><a href="Landing_page.html">Inicio</a></li>
                    <li><a href="Registro.php">Registrarse</a></li>
                    <li><a href="contact.html">Contacto</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Main content -->
    <main>
        
        <div class="login-container">
            <h2>Iniciar sesión</h2><!-- <form action="login.php" method="POST">-->
            <form action="login.php" method="POST">
                <label for="email">Correo electrónico</label>
                <input type="email" id="email" name="email" required placeholder="Ingrese su correo electrónico">

                <label for="password">Contraseña</label>
                <input type="password" id="password" name="password" required placeholder="Ingrese su contraseña"><br><br>

                <button type="submit">Iniciar sesión</button><br><br>
            </form>
            <a href="Registro.php">
                <button>Registrarse</button>
            </a>
            
        </div>
    </main>

    <!-- Footer -->
    <footer>
        <p>&copy; 2024 Mi Tiendita Online. Todos los derechos reservados.</p>
    </footer>
</body>
</html>
