<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['IDUsuario']) || !isset($_POST['accion'])) {
    header("Location: Landing_page.php");
    exit;
}

$usuarioID = $_SESSION['IDUsuario'];
$accion = $_POST['accion'];

switch ($accion) {
    case 'iniciar_chat':
        if (!isset($_POST['vendedor_id'])) {
            header("Location: producto.php");
            exit;
        }

        $vendedorID = (int)$_POST['vendedor_id'];

        if ($usuarioID === $vendedorID) {
            header('Location: producto.php');
            exit;
        }

        $chatHash = ($usuarioID < $vendedorID) ? "$usuarioID-$vendedorID" : "$vendedorID-$usuarioID";

        $stmt = $pdo->prepare("SELECT IDChat FROM chats WHERE ChatHash = ?");
        $stmt->execute([$chatHash]);
        $chat = $stmt->fetch();

        if ($chat) {
            $chatID = $chat['IDChat'];
        } else {
            $stmt = $pdo->prepare("INSERT INTO chats (Usuario1, Usuario2, ChatHash) VALUES (?, ?, ?)");
            $stmt->execute([$usuarioID, $vendedorID, $chatHash]);
            $chatID = $pdo->lastInsertId();
        }

        header("Location: mensajes.php?chat_id=$chatID");
        exit;

    case 'enviar_mensaje':
        if (empty($_POST['mensaje']) || empty($_POST['chat_id'])) {
            header("Location: mensajes.php");
            exit;
        }

        $chatID = $_POST['chat_id'];
        $mensaje = trim($_POST['mensaje']);

        $stmt = $pdo->prepare("SELECT * FROM chats WHERE IDChat = ? AND (Usuario1 = ? OR Usuario2 = ?)");
        $stmt->execute([$chatID, $usuarioID, $usuarioID]);
        $chat = $stmt->fetch();

        if (!$chat) {
            die("No puedes enviar mensajes en este chat.");
        }

        $stmt = $pdo->prepare("INSERT INTO mensajes_chat (IDChat, IDRemitente, Mensaje) VALUES (?, ?, ?)");
        $stmt->execute([$chatID, $usuarioID, $mensaje]);

        header("Location: chat.php?chat_id=$chatID");
        exit;

    case 'enviar_producto_chat':
        if ($_SESSION['Rol'] != 1) {
            die("No autorizado.");
        }

        $chatID = $_POST['chat_id'];
        $nombre = $_POST['nombre'];
        $precio = $_POST['precio'];
        $stock = $_POST['stock'];
        $descripcion = $_POST['descripcion'] ?? '';
        $idCategoria = $_POST['categoria'];

        // 1. Insertar producto
        $stmt = $pdo->prepare("
            INSERT INTO productos (Nombre, Precio, Stock, Descripcion, Estado, Tipo, aprov, IDUsuario, IDCategoria)
            VALUES (?, ?, ?, ?, 1, 0, 1, ?, ?)
        ");
        $stmt->execute([$nombre, $precio, $stock, $descripcion, $usuarioID, $idCategoria]);
        $idProducto = $pdo->lastInsertId();

        // 2. Enviar mensaje con enlace al producto
        $mensaje = "Te comparto este producto: <a href='producto.php?productoID=$idProducto'>Ver producto</a>";

        $stmt = $pdo->prepare("INSERT INTO mensajes_chat (IDChat, IDRemitente, Mensaje) VALUES (?, ?, ?)");
        $stmt->execute([$chatID, $usuarioID, $mensaje]);

        header("Location: chat.php?chat_id=$chatID");
        exit;

    default:
        header("Location: Landing_page.php");
        exit;
}
?>
