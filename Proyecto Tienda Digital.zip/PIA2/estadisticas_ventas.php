<?php
session_start();
require 'config.php';

$idVendedor = $_SESSION['IDUsuario'] ?? null;

if (!$idVendedor) {
    echo "Sesión no iniciada.";
    exit;
}

// Productos vendidos por producto
$stmt = $pdo->prepare("
    SELECT p.Nombre, COUNT(v.IDVenta) AS total_vendidos
    FROM ventas v
    JOIN productos p ON v.IDProducto = p.IDProducto
    WHERE p.IDUsuario = ?
    GROUP BY p.IDProducto
");
$stmt->execute([$idVendedor]);
$ventas = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Total de productos publicados
$stmtPublicados = $pdo->prepare("
    SELECT COUNT(*) FROM productos WHERE IDUsuario = ?
");
$stmtPublicados->execute([$idVendedor]);
$totalPublicados = $stmtPublicados->fetchColumn();

// Total de ventas
$stmtTotalVentas = $pdo->prepare("
    SELECT COUNT(*) FROM ventas v
    JOIN productos p ON v.IDProducto = p.IDProducto
    WHERE p.IDUsuario = ?
");
$stmtTotalVentas->execute([$idVendedor]);
$totalVendidos = $stmtTotalVentas->fetchColumn();

// Fecha de registro del usuario
$stmtRegistro = $pdo->prepare("SELECT FechaRegistro FROM usuarios WHERE IDUsuario = ?");
$stmtRegistro->execute([$idVendedor]);
$fechaRegistro = $stmtRegistro->fetchColumn();
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Lista de Deseos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="listas_detalles.css">
</head>
<body>
<header>
        <div class="container">
            <a href="Landing_page.php"><h1 class="logo">Mi Tiendita Online <img src="imgs/logo.png" width="61" height="55"></h1></a>
            <div class="search-bar">
                <form action="Busqueda.php" method="GET">
                    <input type="text" name="q" placeholder="Buscar productos, marcas o categorías">
                    <button type="submit">Buscar</button>
                </form>
            </div>

            <nav>
                <ul>
                    <?php if (isset($_SESSION['Username'])): ?>
                            <li><a href="ver_lista.php">Listas</a></li>
                        <?php endif; ?>
                    <li><a href="Landing_page.php">Inicio</a></li>
                    <?php if (isset($_SESSION['Rol']) && $_SESSION['Rol'] != 0): ?>
                        <li><a href="publicar_producto.php">Publicar Prod./Serv.</a></li>
                    <?php endif; ?>
                    
                    <?php if (isset($_SESSION['Username'])): ?>
                            <li><a href="perfil.php">Perfil: <?php echo htmlspecialchars($_SESSION['Username']); ?> </a></li>
                    <?php endif; ?>
                    <?php if (isset($_SESSION['Username'])): ?>
                        <li><a href="ver_carrito.php">Carrito</a></li>
                    <?php endif; ?>
                    
                </ul>
            </nav>
        </div>
    </header>
    
    <main class="container mt-4">
        <h2 class="mb-4">Estadísticas de ventas</h2>

        <div class="card mb-4">
            <div class="card-body">
                <p><strong>Productos publicados:</strong> <?= $totalPublicados ?></p>
                <p><strong>Total de productos vendidos:</strong> <?= $totalVendidos ?></p>
                <p><strong>Fecha de registro:</strong> <?= date("d/m/Y", strtotime($fechaRegistro)) ?></p>
            </div>
        </div>

        <h4>Ventas por producto:</h4>
        <ul class="list-group">
            <?php if (count($ventas) > 0): ?>
                <?php foreach ($ventas as $venta): ?>
                    <li class="list-group-item">
                        <?= htmlspecialchars($venta['Nombre']) ?>: <strong><?= $venta['total_vendidos'] ?></strong> vendidos
                    </li>
                <?php endforeach; ?>
            <?php else: ?>
                <li class="list-group-item">No se han realizado ventas aún.</li>
            <?php endif; ?>
        </ul>
    </main>

    <!-- Footer -->
    <footer>
        <p>&copy; 2024 Mi Tiendita Online. Todos los derechos reservados.</p>
    </footer>
</body>
</html>