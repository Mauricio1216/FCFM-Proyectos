<?php

session_start();


if (!isset($_SESSION['Username'])) {
    header("Location: Login.php");
    exit();
}

require 'config.php';

$id_usuario = $_SESSION['IDUsuario']; 

// Consulta que trae los datos y la foto de perfil del usuario en sesion
$stmt = $pdo->prepare("SELECT u.*, f.path 
                       FROM usuarios u
                       LEFT JOIN fotoPerfil f ON u.IDUsuario = f.IDUsuario
                       WHERE u.IDUsuario = ?");
$stmt->execute([$id_usuario]);
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);

// Verificar si encontró al usuario
if (!$usuario) {
    echo "Usuario no encontrado.";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nuevo_nombre = $_POST['name'];
    $nuevo_email = $_POST['email'];
    $nueva_contra = $_POST['password'];
    $nuevo_genero = $_POST['gender'] === 'Femenino' ? 0 : 1;
    $nueva_direccion = $_POST['direccion'];
    $privacidad = isset($_POST['privacidad']) ? (int)$_POST['privacidad'] : 0;

    // Si se quiere actualizar la contraseña
    if (!empty($nueva_contra)) {
        $nueva_contra_hashed = password_hash($nueva_contra, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE usuarios SET Nombre = ?, Email = ?, Contra = ?, Direccion = ?, Genero = ?, Privacidad = ? WHERE IDUsuario = ?");
        $stmt->execute([$nuevo_nombre, $nuevo_email, $nueva_contra_hashed, $nueva_direccion, $nuevo_genero, $privacidad, $id_usuario]);
    } else {
        $stmt = $pdo->prepare("UPDATE usuarios SET Nombre = ?, Email = ?, Direccion = ?, Genero = ?, Privacidad = ? WHERE IDUsuario = ?");
        $stmt->execute([$nuevo_nombre, $nuevo_email, $nueva_direccion, $nuevo_genero, $privacidad, $id_usuario]);
    }

    // Procesar la imagen de perfil si fue enviada
    if (isset($_FILES['profile_pic']) && $_FILES['profile_pic']['error'] === UPLOAD_ERR_OK) {
        $ruta_temporal = $_FILES['profile_pic']['tmp_name'];
        $nombre_archivo = basename($_FILES['profile_pic']['name']);
        $ruta_destino = 'uploads/' . time() . '_' . $nombre_archivo;

        move_uploaded_file($ruta_temporal, $ruta_destino);

        // Revisar si ya tiene una foto de perfil
        $stmtFoto = $pdo->prepare("SELECT * FROM fotoPerfil WHERE IDUsuario = ?");
        $stmtFoto->execute([$id_usuario]);

        if ($stmtFoto->rowCount() > 0) {
            // Actualizar
            $stmtUpdateFoto = $pdo->prepare("UPDATE fotoPerfil SET path = ? WHERE IDUsuario = ?");
            $stmtUpdateFoto->execute([$ruta_destino, $id_usuario]);
        } else {
            // Insertar
            $stmtInsertFoto = $pdo->prepare("INSERT INTO fotoPerfil (path, IDUsuario) VALUES (?, ?)");
            $stmtInsertFoto->execute([$ruta_destino, $id_usuario]);
        }
    }

    header("Location: editar_Perfil.php?actualizado=1");
    exit();
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Perfil</title>
    <link rel="stylesheet" href="editar_perfil_estilos.css"> <!-- Enlace a la hoja de estilos CSS -->
</head>
<body>
    <!-- Barra Superior -->
    <header>
        <div class="container">
            <a href="Landing_page.php"><h1 class="logo">Mi Tiendita Online <img src="imgs/logo.png" width="61" height="55"></h1></a>
            <div class="search-bar">
                <form action="Busqueda.php" method="GET">
                    <input type="text" name="q" placeholder="Buscar productos, marcas o categorías">
                    <button type="submit">Buscar</button>
                </form>
            </div>
            <nav>
                <ul>
                    <?php if (isset($_SESSION['Username'])): ?>
                        <li><a href="ver_lista.php">Listas</a></li>
                    <?php endif; ?>
                    <div class="welcome-user">
                        <?php if (isset($_SESSION['Username'])): ?>
                            <li><a href="perfil_Comp.php">Perfil: <?php echo htmlspecialchars($_SESSION['Username']); ?> </a></li>
                        <?php endif; ?>
                    </div>
                    <?php if (isset($_SESSION['Username'])): ?>
                        <li><a href="ver_carrito.php">Carrito</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Sección de Edición de Perfil -->
    <main>
        <div class="edit-profile-container">
            <h2>Editar Perfil</h2>
            <form action="editar_Perfil.php" method="POST" enctype="multipart/form-data">
                <div class="profile-image">
                    <label for="profile-pic">Foto de perfil:</label><br>
                    <img id="profile-preview" src="<?= $usuario['path'] ? htmlspecialchars($usuario['path']) : 'imgs/default.png' ?>" alt="Foto de perfil" width="150" /><br>

                    <input type="file" id="profile-pic" name="profile_pic" accept="image/*" onchange="previewImage(event)">
                    <br>
                    <br>
                </div>

                <div class="form-group">
                    <label for="name">Nombre:</label>
                    <input type="text" id="name" name="name" value="<?= htmlspecialchars($usuario['Nombre']) ?>" required>
                    <br>
                </div>

                <div class="form-group">
                    <label for="email">Correo electrónico:</label>
                    <input type="email" id="email" name="email" value="<?= htmlspecialchars($usuario['Email']) ?>" required>
                </div>

                <div class="form-group">
                    <label for="password">Contraseña:</label>
                    <input type="password" id="password" name="password" placeholder="Ingrese su nueva contraseña"><br>
                    <small>Deje este campo vacío si no desea cambiar la contraseña.</small>
                    <br>
                </div>

                <div class="form-group">
                    <label for="gender">Genero:</label>
                    <div class="gender-options">
                        <select id="gender" name="gender" required>
                            <option value="Masculino" <?= $usuario['Genero'] ? 'selected' : '' ?>>Masculino</option>
                            <option value="Femenino" <?= !$usuario['Genero'] ? 'selected' : '' ?>>Femenino</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label for="direccion">Dirección:</label>
                    <input type="text" id="direccion" name="direccion" value="<?= htmlspecialchars($usuario['Direccion']) ?>" required>
                    <br><br>
                </div>

                <?php if ($usuario['Rol'] == 0): ?>
                <div class="form-group">
                    <div class="gender-options">
                    <label for="privacidad">Privacidad de la lista de deseos:</label>
                    <select id="privacidad" name="privacidad" required>
                        <option value="0" <?= $usuario['Privacidad'] ? 'selected' : '' ?>>Pública (otros pueden verla)</option>
                        <option value="1" <?= !$usuario['Privacidad'] ? 'selected' : '' ?>>Privada (solo tú puedes verla)</option>
                    </select>
                </div>
                </div>
                <?php endif; ?>

                <div class="form-group">
                    <button type="submit">Actualizar Perfil</button>
                </div>
            </form>
        </div>
    </main>

    <!-- Footer -->
    <footer>
        <p>&copy; 2024 Mi Tiendita Online. Todos los derechos reservados.</p>
    </footer>

    <script>
        function previewImage(event) {
            var reader = new FileReader();
            reader.onload = function(){
                var output = document.getElementById('profile-preview');
                output.src = reader.result;
            }
            reader.readAsDataURL(event.target.files[0]);
        }
    </script>
</body>
</html>
