<?php
session_start();
require 'config.php';

if (!isset($_SESSION['IDUsuario'])) {
    header("Location: Login.php");
    exit();
}

$usuarioID = $_SESSION['IDUsuario'];

// Validar campos de tarjeta (simulado)
if (!isset($_POST['numero'], $_POST['nombre'], $_POST['exp'], $_POST['cvv'])) {
    echo "Datos de tarjeta incompletos.";
    exit();
}

$pdo->beginTransaction();
try {
    $productos = [];

    // Si se trata de compra individual
    if (isset($_POST['productoID'])) {
        $productoID = intval($_POST['productoID']);

        // Traer datos del producto individual
        $stmt = $pdo->prepare("SELECT IDProducto, Stock FROM productos WHERE IDProducto = ?");
        $stmt->execute([$productoID]);
        $producto = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$producto || $producto['Stock'] <= 0) {
            throw new Exception("Producto no disponible o sin stock.");
        }

        $productos[] = $producto;

    } else {
        // Compra grupal desde el carrito
        $stmt = $pdo->prepare("
            SELECT c.IDProducto, p.Stock
            FROM carrito c
            JOIN productos p ON c.IDProducto = p.IDProducto
            WHERE c.IDUsuario = ?
        ");
        $stmt->execute([$usuarioID]);
        $productos = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (empty($productos)) {
            throw new Exception("No hay productos en el carrito.");
        }
    }

    foreach ($productos as $producto) {
        $idProducto = $producto['IDProducto'];
        $stock = $producto['Stock'];

        if ($stock <= 0) {
            throw new Exception("Producto ID $idProducto sin stock.");
        }

        // Descontar stock
        $stmt = $pdo->prepare("UPDATE productos SET Stock = Stock - 1 WHERE IDProducto = ?");
        $stmt->execute([$idProducto]);

        // Verificar nuevo stock y desactivar si es 0
        $stmt = $pdo->prepare("SELECT Stock FROM productos WHERE IDProducto = ?");
        $stmt->execute([$idProducto]);
        $nuevoStock = $stmt->fetchColumn();

        if ($nuevoStock <= 0) {
            $pdo->prepare("UPDATE productos SET Estado = 0 WHERE IDProducto = ?")->execute([$idProducto]);
            $pdo->prepare("DELETE FROM carrito WHERE IDProducto = ?")->execute([$idProducto]);
        }

        // Insertar venta
        $stmt = $pdo->prepare("INSERT INTO ventas (IDProducto, IDComprador) VALUES (?, ?)");
        $stmt->execute([$idProducto, $usuarioID]);
    }

    // Si es compra grupal, limpiar carrito del usuario
    if (!isset($_POST['productoID'])) {
        $pdo->prepare("DELETE FROM carrito WHERE IDUsuario = ?")->execute([$usuarioID]);
    }

    $pdo->commit();
    echo "<script>alert('Pago procesado correctamente. ¡Gracias por tu compra!'); window.location.href = 'Landing_page.php';</script>";

} catch (Exception $e) {
    $pdo->rollBack();
    echo "Error en el pago: " . $e->getMessage();
}
