<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['IDUsuario'])) {
    header("Location: login.php");
    exit;
}

$chatID = $_GET['chat_id'] ?? 0;
$usuarioID = $_SESSION['IDUsuario'];

// Validar que el usuario participa en ese chat
$stmt = $pdo->prepare("SELECT * FROM chats WHERE IDChat = ? AND (Usuario1 = ? OR Usuario2 = ?)");
$stmt->execute([$chatID, $usuarioID, $usuarioID]);
$chat = $stmt->fetch();

if (!$chat) {
    die("No tienes acceso a este chat.");
}

// Obtener mensajes
$stmt = $pdo->prepare("
    SELECT m.*, u.Nombre AS Remitente
    FROM mensajes_chat m
    JOIN usuarios u ON m.IDRemitente = u.IDUsuario
    WHERE m.IDChat = ?
    ORDER BY m.FechaEnvio ASC
");
$stmt->execute([$chatID]);
$mensajes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Obtener categorias para producto
try {
    $stmt = $pdo->prepare('SELECT IDCategoria, Nombre FROM categorias');
    $stmt->execute();
    $categorias = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die('Error al obtener categorías: ' . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat</title>
    <link rel="stylesheet" href="mensajeria.css">
</head>
<body>
    <header>
        <div class="container">
            <a href="Landing_page.php"><h1 class="logo">Mi Tiendita Online <img src="imgs/logo.png" width="61" height="55"></h1></a>
            <div class="search-bar">
                <form action="Busqueda.php" method="GET">
                    <input type="text" name="q" placeholder="Buscar productos, marcas o categorías" required>
                    <button type="submit">Buscar</button>
                </form>
            </div>

            <nav>
                <ul>
                        <?php if (isset($_SESSION['Username'])): ?>
                            <li><a href="ver_lista.php">Listas</a></li>
                        <?php endif; ?>
                    <!--<li><a href="perfil.php">Perfil</a></li>-->
                    <div class="welcome-user">
                        <?php if (isset($_SESSION['Username'])): ?>
                            <li><a href="perfil.php">Perfil: <?php echo htmlspecialchars($_SESSION['Username']); ?> </a></li>
                        <?php endif; ?>
                    </div>
                    <?php if (isset($_SESSION['Username'])): ?>
                        <li><a href="ver_carrito.php">Carrito</a></li>
                    <?php endif; ?>
                    <li><a href="mensajes.php">Mensajes</a></li>
                    <li><a href="Login.php">Cerrar Sesión</a></li>
                    
                </ul>
            </nav>
            
        </div>
    </header>

    <main>
    <h1>Chat</h1>
    <div>
        <div class="chat-mensajes">
        <?php foreach ($mensajes as $mensaje): ?>
            <p>
                <strong><?= htmlspecialchars($mensaje['Remitente']) ?>:</strong>
                <?= nl2br($mensaje['Mensaje']) ?>
                <em>(<?= $mensaje['FechaEnvio'] ?>)</em>
            </p>
        <?php endforeach; ?>
    </div>

    </div>

    <!-- Formulario para enviar mensaje -->
    <form action="api-chat.php" method="POST">
        <input type="hidden" name="accion" value="enviar_mensaje">
        <input type="hidden" name="chat_id" value="<?= $chatID ?>">
        <textarea name="mensaje"></textarea>
        <button type="submit">Enviar</button>
    </form>


    <?php if ($_SESSION['Rol'] == 1): // Si es vendedor ?>
    <h2>Enviar un producto</h2>
        <form action="api-chat.php" method="POST">
        <input type="hidden" name="accion" value="enviar_producto_chat">
        <input type="hidden" name="chat_id" value="<?= $chatID ?>">
        <!-- otros campos del producto -->
        Nombre: <input type="text" name="nombre"><br>
        Precio: <input type="number" name="precio"><br>
        Stock: <input type="number" name="stock"><br>
        Descripcion: <textarea name="descripcion"></textarea><br>
        Categoria: <select id="categoria" name="categoria" required>
                    <?php foreach ($categorias as $categoria): ?>
                        <option value="<?php echo $categoria['IDCategoria']; ?>">
                            <?php echo htmlspecialchars($categoria['Nombre']); ?>
                        </option>
                    <?php endforeach; ?>
                </select><br>
        <button type="submit">Enviar producto</button>
    </form>
    <?php endif; ?>

    </main>

</body>
</html>
