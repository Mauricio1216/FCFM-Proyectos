<?php
session_start();
require 'config.php';

// Insertar nueva categoría si es vendedor
if (
    $_SERVER['REQUEST_METHOD'] === 'POST' && 
    isset($_POST['nueva_categoria']) &&
    isset($_SESSION['Rol']) && 
    $_SESSION['Rol'] == 1 // Solo vendedores
) {
    $nombreCategoria = trim($_POST['nueva_categoria']);
    $descripcionCategoria = trim($_POST['descripcion_categoria']);

    if (!empty($nombreCategoria)) {
        $stmt = $pdo->prepare("INSERT INTO categorias (Nombre, Descripcion) VALUES (?, ?)");
        $stmt->execute([$nombreCategoria, $descripcionCategoria]);
    }
}

// Obtener todas las categorías para el combo box
$stmt = $pdo->query("SELECT * FROM categorias");
$categorias = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Filtrar productos por categoría si se seleccionó una
$idCategoriaSeleccionada = isset($_GET['categoria']) ? intval($_GET['categoria']) : 0;

if ($idCategoriaSeleccionada > 0) {
    $stmt = $pdo->prepare("
        SELECT p.*, u.Username, m.path, c.Nombre AS CategoriaNombre
        FROM productos p
        JOIN usuarios u ON p.IDUsuario = u.IDUsuario
        JOIN categorias c ON p.IDCategoria = c.IDCategoria
        LEFT JOIN (
            SELECT IDProducto, MIN(path) AS path
            FROM multimediaPublicacion
            GROUP BY IDProducto
        ) m ON p.IDProducto = m.IDProducto
        WHERE p.aprov = 1 AND p.Stock > 0 AND p.IDCategoria = ?
    ");
    $stmt->execute([$idCategoriaSeleccionada]);
    $resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    $resultados = [];
}
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página de Inicio</title>
    <link rel="stylesheet" href="Categorias.css"> <!-- Enlace a la hoja de estilos CSS -->
</head>
<body>
    <!-- Barra Superior -->
    <header>
        <div class="container">
            <a href="Landing_page.php"><h1 class="logo">Mi Tiendita Online <img src="imgs/logo.png" width="61" height="55"></h1></a>
            <div class="search-bar">
                <form action="Busqueda.php" method="GET">
                    <input type="text" name="q" placeholder="Buscar productos, marcas o categorías" required>
                    <button type="submit">Buscar</button>
                </form>
            </div>

            <nav>
                <ul>
                <?php if (isset($_SESSION['Username'])): ?>
                            <li><a href="ver_lista.php">Listas</a></li>
                        <?php endif; ?>
                    <?php if (isset($_SESSION['Rol']) && $_SESSION['Rol'] != 0): ?>
                        <li><a href="publicar_producto.php">Publicar Prod./Serv.</a></li>
                    <?php endif; ?>
                    <div class="welcome-user">
                        <?php if (isset($_SESSION['Username'])): ?>
                            <li><a href="perfil.php">Perfil: <?php echo htmlspecialchars($_SESSION['Username']); ?> </a></li>
                        <?php endif; ?>
                    </div>
                    <?php if (isset($_SESSION['Username'])): ?>
                        <li><a href="ver_carrito.php">Carrito</a></li>
                    <?php endif; ?>
                    <li><a href="mensajes.html">Mensajes</a></li>
                    
                </ul>
            </nav>
            
        </div>
    </header>

    <main>

    <br>

    <!-- Formulario para agregar nueva categoría -->
    <?php if (isset($_SESSION['Rol']) && $_SESSION['Rol'] == 1): ?>
        <h2>Agregar nueva categoría</h2>
        <form method="POST" action="Categorias.php">
            <input type="text" name="nueva_categoria" placeholder="Nombre de categoría" required>
            <input type="text" name="descripcion_categoria" placeholder="Descripción (opcional)">
            <button type="submit">Agregar Categoría</button>
        </form>
        <br>
    <?php endif; ?>


    <br>

    <h2>Buscar productos por categoría</h2>

    <!-- Formulario para seleccionar categoría -->
    <form method="GET" action="Categorias.php">
        <label for="categoria">Selecciona una categoría:</label>
        <select name="categoria" id="categoria">
            <option value="0">-- Todas las categorías --</option>
            <?php foreach ($categorias as $categoria): ?>
                <option value="<?php echo $categoria['IDCategoria']; ?>"
                    <?php if ($categoria['IDCategoria'] == $idCategoriaSeleccionada) echo 'selected'; ?>>
                    <?php echo htmlspecialchars($categoria['Nombre']); ?>
                </option>
            <?php endforeach; ?>
        </select>
        <button type="submit">Buscar</button>
    </form>

    <br>

        <?php if ($idCategoriaSeleccionada > 0): ?>
            <h3>Productos de la categoría seleccionada:</h3>
        <?php endif; ?>

        <?php if (count($resultados) === 0): ?>
            <p>No se encontraron productos para esta categoría.</p>
        <?php else: ?>
            <div class="productos-grid">
                <?php foreach ($resultados as $producto): ?>
                    <div class="producto-card">
                        <a href="Producto.php?productoID=<?php echo $producto['IDProducto']; ?>">
                            <h3><?php echo htmlspecialchars($producto['Nombre']); ?></h3>
                            <?php if (!empty($producto['path'])): ?>
                                <?php
                                $ext = strtolower(pathinfo($producto['path'], PATHINFO_EXTENSION));
                                if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])): ?>
                                    <img src="<?php echo htmlspecialchars($producto['path']); ?>" width="150">
                                <?php elseif (in_array($ext, ['mp4', 'webm', 'ogg'])): ?>
                                    <video src="<?php echo htmlspecialchars($producto['path']); ?>" width="150" controls></video>
                                <?php endif; ?>
                            <?php endif; ?>
                            <p><strong>Precio:</strong> $<?php echo htmlspecialchars($producto['Precio']); ?></p>
                            <p><strong>Vendedor:</strong> <?php echo htmlspecialchars($producto['Username']); ?></p>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

    </main>

    <footer> <!-- Tu footer aquí --> </footer>
</body>
</html>