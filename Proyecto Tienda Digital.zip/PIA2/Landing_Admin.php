<?php session_start(); 

if (!isset($_SESSION['Username'])) {
    header("Location: Login.php");
    exit();
}

if ($_SESSION['Rol'] != 2) {
    // Redirigir en caso de que el usuario no sea un admin
    header("Location: Login.php");
    exit();
}

require 'config.php';

$id_usuario = $_SESSION['IDUsuario']; 

// Consulta para obtener todos los productos publicados
$stmtProductos = $pdo->query("
    SELECT p.*, u.Username, m.path
    FROM productos p
    JOIN usuarios u ON p.IDUsuario = u.IDUsuario
    LEFT JOIN (
        SELECT IDProducto, MIN(path) AS path
        FROM multimediaPublicacion
        GROUP BY IDProducto
    ) m ON p.IDProducto = m.IDProducto
    WHERE p.aprov = 1
");

$productos = $stmtProductos->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página de Inicio</title>
    <link rel="stylesheet" href="LandPage_Estilo.css"> <!-- Enlace a la hoja de estilos CSS -->
</head>
<body>
    <!-- Barra Superior -->
    <header>
        <div class="container">
            <a href="Landing_Admin.html"><h1 class="logo">Mi Tiendita Online <img src="imgs/logo.png" width="61" height="55"></h1></a>
            <div class="search-bar">
                <input type="text" placeholder="Buscar productos, marcas o categorías">
                <button type="submit">Buscar</button>
            </div>
            <nav>
                <ul>
                    <?php if (isset($_SESSION['Username'])): ?>
                        <li><a href="Solicitudes.php">Solicitudes de productos</a></li>
                    <?php endif; ?>
                    <li><a href="Login.php">Cerrar Sesión</a></li>
                    
                </ul>
            </nav>
        </div>
    </header>

    <!-- Sección principal en blanco por ahora -->
    <main>
        <section class="welcome">
            <h2>Bienvenido a Mi Tienda Online</h2>
            <p>Explora los productos más populares y encuentra lo que necesitas.</p>
        </section>
    </main>

    <!-- Footer -->
    <footer>
        <p>&copy; 2024 Mi Tiendita Online. Todos los derechos reservados.</p>
    </footer>
</body>
</html>
