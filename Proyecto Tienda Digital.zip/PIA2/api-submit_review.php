<?php
session_start();
require 'config.php';

if (!isset($_SESSION['IDUsuario'])) {
    header("Location: Login.php");
    exit;
}

$idUsuario = $_SESSION['IDUsuario'];
$idProducto = $_POST['productoID'];
$comentario = trim($_POST['comentario']);
$rating = intval($_POST['rating']);
$fecha = date('Y-m-d H:i:s');

// Insertar comentario
$stmtComentario = $pdo->prepare("
    INSERT INTO comentarios (Descripcion, Fecha, IDUsuario, IDProducto)
    VALUES (:comentario, :fecha, :usuario, :producto)
");
$stmtComentario->execute([
    'comentario' => $comentario,
    'fecha' => $fecha,
    'usuario' => $idUsuario,
    'producto' => $idProducto
]);

// Insertar o actualizar calificación (evita duplicados)
$stmtCheck = $pdo->prepare("SELECT IDCalificaciones FROM calificaciones WHERE IDUsuario = :usuario AND IDProducto = :producto");
$stmtCheck->execute(['usuario' => $idUsuario, 'producto' => $idProducto]);

if ($stmtCheck->rowCount() > 0) {
    $stmtUpdate = $pdo->prepare("
        UPDATE calificaciones
        SET Valor = :valor
        WHERE IDUsuario = :usuario AND IDProducto = :producto
    ");
    $stmtUpdate->execute([
        'valor' => $rating,
        'usuario' => $idUsuario,
        'producto' => $idProducto
    ]);
} else {
    $stmtInsert = $pdo->prepare("
        INSERT INTO calificaciones (Valor, IDUsuario, IDProducto)
        VALUES (:valor, :usuario, :producto)
    ");
    $stmtInsert->execute([
        'valor' => $rating,
        'usuario' => $idUsuario,
        'producto' => $idProducto
    ]);
}

header("Location: producto.php?productoID=$idProducto");
exit;
