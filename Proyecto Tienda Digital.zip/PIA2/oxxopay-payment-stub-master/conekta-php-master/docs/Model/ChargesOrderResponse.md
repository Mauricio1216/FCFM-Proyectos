# # ChargesOrderResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**has_more** | **bool** | Indicates if there are more pages to be requested |
**object** | **string** | Object type, in this case is list |
**data** | [**\Conekta\Model\ChargesOrderResponseAllOfData[]**](ChargesOrderResponseAllOfData.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
