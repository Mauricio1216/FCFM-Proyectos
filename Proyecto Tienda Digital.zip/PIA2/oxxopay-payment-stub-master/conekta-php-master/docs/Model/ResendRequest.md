# # ResendRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**webhooks_ids** | **string[]** | webhooks ids to resend event |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
