# # UpdateProduct

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**antifraud_info** | **array<string,object>** |  | [optional]
**description** | **string** |  | [optional]
**sku** | **string** |  | [optional]
**name** | **string** |  | [optional]
**unit_price** | **int** |  | [optional]
**quantity** | **int** |  | [optional]
**tags** | **string[]** |  | [optional]
**brand** | **string** |  | [optional]
**metadata** | **array<string,string>** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
