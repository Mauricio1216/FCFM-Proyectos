# # OrderNextActionResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**redirect_to_url** | [**\Conekta\Model\OrderNextActionResponseRedirectToUrl**](OrderNextActionResponseRedirectToUrl.md) |  | [optional]
**type** | **string** | Indicates the type of action to be taken | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
