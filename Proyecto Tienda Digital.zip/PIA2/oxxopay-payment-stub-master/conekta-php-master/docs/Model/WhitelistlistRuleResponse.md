# # WhitelistlistRuleResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **string** | Whitelist rule id | [optional]
**field** | **string** | field used for whitelists rule | [optional]
**value** | **string** | value used for whitelists rule | [optional]
**description** | **string** | use an description for whitelisted rule | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
