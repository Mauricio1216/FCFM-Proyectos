# # ChargeResponseRefundsData

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **int** |  |
**auth_code** | **string** |  | [optional]
**created_at** | **int** |  |
**expires_at** | **int** | refund expiration date | [optional]
**id** | **string** |  |
**object** | **string** |  |
**status** | **string** | refund status | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
