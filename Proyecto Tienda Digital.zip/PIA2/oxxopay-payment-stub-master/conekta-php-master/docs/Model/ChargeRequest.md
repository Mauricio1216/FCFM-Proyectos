# # ChargeRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **int** | Amount to be charged in cents | [optional]
**payment_method** | [**\Conekta\Model\ChargeRequestPaymentMethod**](ChargeRequestPaymentMethod.md) |  |
**reference_id** | **string** | Custom reference to add to the charge | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
