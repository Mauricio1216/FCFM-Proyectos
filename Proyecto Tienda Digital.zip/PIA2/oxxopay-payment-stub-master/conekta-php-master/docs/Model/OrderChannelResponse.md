# # OrderChannelResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**segment** | **string** |  | [optional]
**checkout_request_id** | **string** |  | [optional]
**checkout_request_type** | **string** |  | [optional]
**id** | **string** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
