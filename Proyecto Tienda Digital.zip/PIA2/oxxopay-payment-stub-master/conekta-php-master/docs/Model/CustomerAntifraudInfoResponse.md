# # CustomerAntifraudInfoResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**first_paid_at** | **int** |  | [optional]
**account_created_at** | **int** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
