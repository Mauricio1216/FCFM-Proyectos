# # Payout

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**payout_method** | [**\Conekta\Model\PayoutMethod**](PayoutMethod.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
