# # TokenCheckout

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returns_control_on** | **string** | It is a value that allows identifying the returns control on. | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
