# # PlanResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **int** |  | [optional]
**created_at** | **int** |  | [optional]
**currency** | **string** |  | [optional]
**expiry_count** | **int** |  | [optional]
**frequency** | **int** |  | [optional]
**id** | **string** |  | [optional]
**interval** | **string** |  | [optional]
**livemode** | **bool** |  | [optional]
**name** | **string** |  | [optional]
**object** | **string** |  | [optional]
**trial_period_days** | **int** |  | [optional]
**max_retries** | **int** |  | [optional]
**retry_delay_hours** | **int** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
