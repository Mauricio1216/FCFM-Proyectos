# # CompanyPayoutDestinationResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**object** | **string** | The resource&#39;s type | [optional]
**currency** | **string** | currency of the receiving account | [optional]
**account_holder_name** | **string** | Name of the account holder | [optional]
**bank** | **string** | Name of the bank | [optional]
**type** | **string** | Type of the payout destination | [optional]
**account_number** | **string** | Account number of the receiving account | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
