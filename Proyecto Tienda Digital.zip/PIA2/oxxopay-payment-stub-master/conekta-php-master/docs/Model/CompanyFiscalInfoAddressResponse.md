# # CompanyFiscalInfoAddressResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**object** | **string** | The resource&#39;s type | [optional]
**street1** | **string** | Street Address | [optional]
**street2** | **string** | Colonia | [optional]
**city** | **string** | City | [optional]
**state** | **string** | State | [optional]
**country** | **string** | Country | [optional]
**postal_code** | **string** | Postal code | [optional]
**external_number** | **string** | Street number | [optional]
**internal_number** | **string** | Unit / apartment number | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
