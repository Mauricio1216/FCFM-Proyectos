# # CreateRiskRulesData

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **string** | Description of the rule |
**field** | **string** | Field to be used for the rule |
**value** | **string** | Value to be used for the rule |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
