# # PaymentMethodCashResponseAllOfAgreements

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**agreement** | **string** | Agreement number, you can use this number to pay in the store/bbva | [optional]
**provider** | **string** | Provider name, you can use this to know where to pay | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
