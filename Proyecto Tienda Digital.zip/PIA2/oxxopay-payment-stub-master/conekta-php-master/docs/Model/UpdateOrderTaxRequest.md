# # UpdateOrderTaxRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **int** | The amount to be collected for tax in cents | [optional]
**description** | **string** | description or tax&#39;s name | [optional]
**metadata** | **array<string,object>** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
