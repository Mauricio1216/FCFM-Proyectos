# # EventResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**created_at** | **int** |  | [optional]
**data** | **array<string,mixed>** |  | [optional]
**id** | **string** |  | [optional]
**livemode** | **bool** |  | [optional]
**object** | **string** |  | [optional]
**type** | **string** |  | [optional]
**webhook_logs** | [**\Conekta\Model\WebhookLog[]**](WebhookLog.md) |  | [optional]
**webhook_status** | **string** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
