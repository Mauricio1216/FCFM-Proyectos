# # DeletedBlacklistRuleResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **string** | Blacklist rule id | [optional]
**field** | **string** | field used for blacklists rule deleted | [optional]
**value** | **string** | value used for blacklists rule deleted | [optional]
**description** | **string** | use an description for blacklisted rule | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
