# # Error

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**details** | [**\Conekta\Model\DetailsError[]**](DetailsError.md) |  | [optional]
**log_id** | **string** | log id | [optional]
**type** | **string** |  | [optional]
**object** | **string** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
