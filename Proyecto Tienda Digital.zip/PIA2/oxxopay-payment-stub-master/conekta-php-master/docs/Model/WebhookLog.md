# # WebhookLog

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**failed_attempts** | **int** |  | [optional]
**id** | **string** |  | [optional]
**last_attempted_at** | **int** |  | [optional]
**last_http_response_status** | **int** |  | [optional]
**object** | **string** |  | [optional]
**response_data** | **array<string,mixed>** |  | [optional]
**url** | **string** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
