# # OrderResponseCustomerInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**customer_custom_reference** | **string** | Custom reference | [optional]
**name** | **string** |  | [optional]
**email** | **string** |  | [optional]
**phone** | **string** |  | [optional]
**corporate** | **bool** |  | [optional] [default to false]
**object** | **string** |  | [optional]
**customer_id** | **string** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
