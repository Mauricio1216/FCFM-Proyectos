<?php
session_start();
require 'config.php';

if (!isset($_SESSION['IDUsuario']) || !isset($_POST['accion']) || !isset($_POST['productoID'])) {
    header("Location: Landing_page.php");
    exit;
}

$usuarioID = $_SESSION['IDUsuario'];
$productoID = intval($_POST['productoID']);
$accion = $_POST['accion'];

switch ($accion) {
    case 'agregar_a_lista':
        // Verificar si ya está en la lista
        $stmt = $pdo->prepare("SELECT 1 FROM lista WHERE IDUsuario = ? AND IDProducto = ?");
        $stmt->execute([$usuarioID, $productoID]);

        if ($stmt->rowCount() == 0) {
            $insert = $pdo->prepare("INSERT INTO lista (IDUsuario, IDProducto) VALUES (?, ?)");
            $insert->execute([$usuarioID, $productoID]);
        }

        header("Location: ver_lista.php");
        exit;

    case 'agregar_al_carrito':
        // Verificar si ya está en el carrito
        $stmt = $pdo->prepare("SELECT 1 FROM carrito WHERE IDUsuario = ? AND IDProducto = ?");
        $stmt->execute([$usuarioID, $productoID]);

        if ($stmt->rowCount() == 0) {
            $insert = $pdo->prepare("INSERT INTO carrito (IDUsuario, IDProducto) VALUES (?, ?)");
            $insert->execute([$usuarioID, $productoID]);
        }

        header("Location: ver_carrito.php");
        exit;

    case 'eliminar_de_lista':
        $delete = $pdo->prepare("DELETE FROM lista WHERE IDUsuario = ? AND IDProducto = ?");
        $delete->execute([$usuarioID, $productoID]);
        header("Location: ver_lista.php");
        exit;

    case 'eliminar_del_carrito':
        $delete = $pdo->prepare("DELETE FROM carrito WHERE IDUsuario = ? AND IDProducto = ?");
        $delete->execute([$usuarioID, $productoID]);
        header("Location: ver_carrito.php");
        exit;

    default:
        header("Location: Landing_page.php");
        exit;
}
?>
