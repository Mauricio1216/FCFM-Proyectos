<?php
$host = 'localhost';
$dbname = 'pia2';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    error_log('Error de conexión: ' . $e->getMessage());

    if (ob_get_length()) {
        ob_clean(); // Borra antes de imprimir
    }

    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Error al conectar a la base de datos']);
    exit;
}
?>