<?php session_start(); 

if (!isset($_SESSION['Username'])) {
    header("Location: Login.php");
    exit();
}

if ($_SESSION['Rol'] != 1) {
    // Redirigir en caso de que el usuario no sea un vendedor
    header("Location: Land_page_comp.php");
    exit();
}

require 'config.php';

$id_usuario = $_SESSION['IDUsuario']; 

// Consulta para obtener todos los productos publicados
$stmtProductos = $pdo->query("
    SELECT p.*, u.Username, m.path
    FROM productos p
    JOIN usuarios u ON p.IDUsuario = u.IDUsuario
    LEFT JOIN (
        SELECT IDProducto, MIN(path) AS path
        FROM multimediaPublicacion
        GROUP BY IDProducto
    ) m ON p.IDProducto = m.IDProducto
    WHERE p.aprov = 1 AND p.Stock > 0
");

$productos = $stmtProductos->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página de Inicio</title>
    <link rel="stylesheet" href="LandPage_Estilo.css"> <!-- Enlace a la hoja de estilos CSS -->
</head>
<body>
    <!-- Barra Superior -->
    <header>
        <div class="container">
            <a href="Landing_page.php"><h1 class="logo">Mi Tiendita Online <img src="imgs/logo.png" width="61" height="55"></h1></a>
            <div class="search-bar">
                <form action="Busqueda.php" method="GET">
                    <input type="text" name="q" placeholder="Buscar productos, marcas o categorías" required>
                    <button type="submit">Buscar</button>
                </form>
            </div>

            <nav>
                <ul>
                        <?php if (isset($_SESSION['Username'])): ?>
                            <li><a href="ver_lista.php">Listas</a></li>
                        <?php endif; ?>
                    <li><a href="publicar_producto.php">Publicar Prod./Serv.</a></li>
                    <?php if (isset($_SESSION['Username'])): ?>
                        <li><a href="Categorias.php">Categorias</a></li>
                    <?php endif; ?>
                    <!--<li><a href="perfil.php">Perfil</a></li>-->
                    <div class="welcome-user">
                        <?php if (isset($_SESSION['Username'])): ?>
                            <li><a href="perfil.php">Perfil: <?php echo htmlspecialchars($_SESSION['Username']); ?> </a></li>
                        <?php endif; ?>
                    </div>
                    <?php if (isset($_SESSION['Username'])): ?>
                        <li><a href="ver_carrito.php">Carrito</a></li>
                    <?php endif; ?>
                    <li><a href="mensajes.php">Mensajes</a></li>
                    <li><a href="Login.php">Cerrar Sesión</a></li>
                    
                </ul>
            </nav>
            
        </div>
    </header>

    <!-- Sección principal en blanco por ahora -->
    <main>
        <section class="welcome">
            <h2>Bienvenido a Mi Tienda Online</h2>
            <p>Explora los productos más populares y encuentra lo que necesitas.</p>
        </section>
        <br><br>
        <section>
        <?php if (count($productos) === 0): ?>
            <p>Aún no se han publicado productos.</p>
        <?php else: ?>
            <div class="productos-grid">
            <?php foreach ($productos as $producto): ?>
                <div class="producto-card">
                    <a href="Producto.php?productoID=<?php echo $producto['IDProducto']; ?>">
                        <img src="<?php echo htmlspecialchars($producto['path']); ?>" alt="Imagen del producto" width="200" height="150">
                        <h3><?php echo htmlspecialchars($producto['Nombre']); ?></h3>
                        <h3>Precio: $<?php echo htmlspecialchars($producto['Precio']); ?></h3>
                    </a>
                </div>
            <?php endforeach; ?>
            </div>
        <?php endif; ?>
        </section>
    </main>

    <!-- Footer -->
    <footer>
        <p>&copy; 2024 Mi Tiendita Online. Todos los derechos reservados.</p>
    </footer>
</body>
</html>