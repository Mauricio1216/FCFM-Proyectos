<?php
session_start();
require 'config.php';

$query = isset($_GET['q']) ? trim($_GET['q']) : '';

if ($query === '') {
    echo "No se ingresó ningún término de búsqueda.";
    exit();
}

// Buscar productos cuyo nombre coincida (consulta existente)
$stmtProductos = $pdo->prepare("
    SELECT p.*, u.Username, m.path
    FROM productos p
    JOIN usuarios u ON p.IDUsuario = u.IDUsuario
    LEFT JOIN (
        SELECT IDProducto, MIN(path) AS path
        FROM multimediaPublicacion
        GROUP BY IDProducto
    ) m ON p.IDProducto = m.IDProducto
    WHERE p.aprov = 1 AND p.Stock > 0 AND p.Nombre LIKE ?
");
$stmtProductos->execute(['%' . $query . '%']);
$resultadosProductos = $stmtProductos->fetchAll(PDO::FETCH_ASSOC);

// Nueva consulta para buscar usuarios (solo si privacidad = 0)
$stmtUsuarios = $pdo->prepare("
    SELECT u.IDUsuario, u.Username, fp.path AS foto_perfil
    FROM usuarios u
    LEFT JOIN fotoPerfil fp ON u.IDUsuario = fp.IDUsuario
    WHERE u.Privacidad = 0 AND u.Username LIKE ?
    LIMIT 10
");
$stmtUsuarios->execute(['%' . $query . '%']);
$resultadosUsuarios = $stmtUsuarios->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultados de búsqueda</title>
    <link rel="stylesheet" href="LandPage_Estilo.css">
    <style>
        /* Estilos adicionales para la nueva sección */
        .resultados-container {
            display: flex;
            gap: 30px;
            margin-top: 20px;
        }
        
        .seccion-usuarios {
            width: 300px;
            background-color:#ffd59a;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
           margin-right: 100px;
        }
        
        .seccion-productos {
            flex: 1;
        }
        
        .usuario-card {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 15px;
            padding: 10px;
            border-radius: 5px;
            transition: background-color 0.2s;
           
        }
        
        .usuario-card:hover {
            background-color: #e9ecef;
        }
        
        .usuario-card img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
        }
        
        .usuario-info {
            flex: 1;
        }
        
        .usuarios-titulo {
            font-size: 1.2rem;
            color:rgb(250, 250, 250);
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #dee2e6;
        }
        
        @media (max-width: 768px) {
            .resultados-container {
                flex-direction: column;
            }
            
            .seccion-usuarios {
                width: 100%;
                order: -1;
            }
        }
    </style>
</head>
<body>
    <!-- Barra Superior (manteniendo tu estructura actual) -->
    <header>
        <div class="container">
            <a href="Landing_page.php"><h1 class="logo">Mi Tiendita Online <img src="imgs/logo.png" width="61" height="55"></h1></a>
            <div class="search-bar">
                <form action="Busqueda.php" method="GET">
                    <input type="text" name="q" placeholder="Buscar productos, marcas o categorías" required value="<?php echo htmlspecialchars($query); ?>">
                    <button type="submit">Buscar</button>
                </form>
            </div>

            <nav>
                <ul>
                <?php if (isset($_SESSION['Username'])): ?>
                            <li><a href="ver_lista.php">Listas</a></li>
                        <?php endif; ?>
                     <?php if (isset($_SESSION['Rol']) && $_SESSION['Rol'] != 0): ?>
                        <li><a href="publicar_producto.php">Publicar Prod./Serv.</a></li>
                    <?php endif; ?>
                    <div class="welcome-user">
                        <?php if (isset($_SESSION['Username'])): ?>
                            <li><a href="perfil.php">Perfil: <?php echo htmlspecialchars($_SESSION['Username']); ?> </a></li>
                        <?php endif; ?>
                    </div>
                    <?php if (isset($_SESSION['Username'])): ?>
                        <li><a href="ver_carrito.php">Carrito</a></li>
                    <?php endif; ?>
                    <li><a href="mensajes.php">Mensajes</a></li>
                    
                </ul>
            </nav>
        </div>
    </header>

    <main class="container">
        <h2>Resultados para: "<?php echo htmlspecialchars($query); ?>"</h2>
        
        <div class="resultados-container">
            <!-- Sección principal de productos (manteniendo tu estructura) -->
            <div class="seccion-productos">
                <?php if (count($resultadosProductos) === 0): ?>
                    <p>No se encontraron productos con ese nombre.</p>
                <?php else: ?>
                    <div class="productos-grid">
                        <?php foreach ($resultadosProductos as $producto): ?>
                            <div class="producto-card">
                                <a href="Producto.php?productoID=<?php echo $producto['IDProducto']; ?>">
                                <h3><?php echo htmlspecialchars($producto['Nombre']); ?></h3>

                                <?php if (!empty($producto['path'])): ?>
                                    <?php 
                                        $ext = strtolower(pathinfo($producto['path'], PATHINFO_EXTENSION));
                                        if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])): ?>
                                            <img src="<?php echo htmlspecialchars($producto['path']); ?>" width="150">
                                        <?php elseif (in_array($ext, ['mp4', 'webm', 'ogg'])): ?>
                                            <video src="<?php echo htmlspecialchars($producto['path']); ?>" width="150" controls></video>
                                        <?php endif; ?>
                                <?php endif; ?>

                                <p><strong>Precio:</strong> $<?php echo htmlspecialchars($producto['Precio']); ?></p>
                                <p><strong>Vendedor:</strong> <?php echo htmlspecialchars($producto['Username']); ?></p>
                                </a>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Nueva sección de usuarios -->
            <?php if (count($resultadosUsuarios) > 0): ?>
            <div class="seccion-usuarios">
                <div class="usuarios-titulo">Usuarios encontrados</div>
                <?php foreach ($resultadosUsuarios as $usuario): ?>
                    <a href="perfil.php?IDUsuario=<?php echo $usuario['IDUsuario']; ?>" class="usuario-card">
                        <?php if (!empty($usuario['foto_perfil'])): ?>
                            <img src="<?php echo htmlspecialchars($usuario['foto_perfil']); ?>" alt="Foto de perfil">
                        <?php else: ?>
                            <img src="imgs/avatar-default.png" alt="Foto de perfil predeterminada">
                        <?php endif; ?>
                        <div class="usuario-info">
                            <strong><?php echo htmlspecialchars($usuario['Username']); ?></strong>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
    </main>

    <footer>
        <p>&copy; 2024 Mi Tiendita Online. Todos los derechos reservados.</p>
    </footer>
</body>
</html>