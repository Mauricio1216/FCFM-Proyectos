<?php
// Iniciar sesión si no se ha iniciado
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include('config.php');

// Verificar si el usuario está en sesión
$id_usuario = isset($_SESSION['IDUsuario']) ? $_SESSION['IDUsuario'] : null;

// Consulta para obtener todos los productos publicados
$stmtProductos = $pdo->query("
    SELECT p.*, u.Username, m.path
    FROM productos p
    JOIN usuarios u ON p.IDUsuario = u.IDUsuario
    LEFT JOIN (
        SELECT IDProducto, MIN(path) AS path
        FROM multimediaPublicacion
        GROUP BY IDProducto
    ) m ON p.IDProducto = m.IDProducto
    WHERE p.aprov = 1
");

$productos = $stmtProductos->fetchAll(PDO::FETCH_ASSOC);
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página de Inicio</title>
    <link rel="stylesheet" href="LandPage_Estilo.css"> <!-- Enlace a la hoja de estilos CSS -->
</head>
<body>
    <!-- Barra Superior -->
    <header>
        <div class="container">
            <a href="index.php"><h1 class="logo">Mi Tiendita Online <img src="imgs/logo.png" width="61" height="55"></h1></a>
            
            <nav>
                <ul>
                    <?php if (!$id_usuario): ?>
                        <a href="Registro.php" id="regist" name="regist">Registro</a>
                        <a href="Login.php" id="inicio" name="inicio">Iniciar Sesión</a>
                    <?php else: ?>
                        <a href="Landing_page.php" id="inicio" name="inicio">Inicio</a>
                    <?php endif; ?>
                </ul>
            </nav>

        </div>
    </header>

    <!-- Sección principal en blanco por ahora -->
    <main>
        <section class="welcome">
            <h2>Bienvenido a Mi Tienda Online</h2>
            <p>Explora los productos más populares y encuentra lo que necesitas.</p>
        </section>
    </main>

    <!-- Footer -->
    <footer>
        <p>&copy; 2024 Mi Tiendita Online. Todos los derechos reservados.</p>
    </footer>
</body>
</html>