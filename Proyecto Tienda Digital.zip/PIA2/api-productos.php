<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

if (!isset($_SESSION['IDUsuario'])) {
    echo json_encode(['success' => false, 'message' => 'Usuario no autenticado']);
    exit;
}


// Iniciar el buffer para evitar cualquier salida no deseada
ob_start();

header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Credentials: true");


require_once 'config.php';

// Obtener el ID del usuario desde sesión o POST
$id_usuario = $_SESSION['IDUsuario'] ?? (isset($_POST['IDUsuario']) ? (int)$_POST['IDUsuario'] : 0);

if ($id_usuario === 0) {
    http_response_code(401);
    ob_clean();
    echo json_encode(['success' => false, 'message' => 'Usuario no autenticado']);
    exit;
}

// Manejo para POST: Registrar producto
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $productoID = isset($_POST['productoID']) ? intval($_POST['productoID']) : 0;
    $esEdicion = $productoID > 0;

    try {
        // Validar campos requeridos
        $required = ['nombre', 'descripcion', 'categoria', 'estado'];
        foreach ($required as $campo) {
            if (empty($_POST[$campo])) {
                throw new Exception("El campo '$campo' es requerido.");
            }
        }

        $nombre = htmlspecialchars($_POST['nombre']);
        $descripcion = htmlspecialchars($_POST['descripcion']);
        $cantidad = isset($_POST['cantidad']) ? (int)$_POST['cantidad'] : 0;
        $precio = isset($_POST['precio']) ? (float)$_POST['precio'] : 0.0;
        $categoria = (int)$_POST['categoria'];
        $estado = (int)$_POST['estado'];

        $multimedia = [];

        // Subir imágenes
        if (!empty($_FILES['imagen']['name'][0])) {
            $imgDir = 'uploads/productos/';
            if (!is_dir($imgDir)) mkdir($imgDir, 0777, true);

            foreach ($_FILES['imagen']['tmp_name'] as $key => $tmp) {
                $archivoNombre = uniqid() . '_' . basename($_FILES['imagen']['name'][$key]);
                $ruta = $imgDir . $archivoNombre;
                if (move_uploaded_file($tmp, $ruta)) {
                    $multimedia[] = $ruta;
                }
            }
        }

        // Subir video
        if (!empty($_FILES['videoUpload']['tmp_name'])) {
            $videoDir = 'uploads/videos/';
            if (!is_dir($videoDir)) mkdir($videoDir, 0777, true);

            $videoNombre = uniqid() . '_' . basename($_FILES['videoUpload']['name']);
            $rutaVideo = $videoDir . $videoNombre;
            if (move_uploaded_file($_FILES['videoUpload']['tmp_name'], $rutaVideo)) {
                $multimedia[] = $rutaVideo;
            }
        }

        // Insertar producto
        if ($esEdicion) {
            $stmt = $pdo->prepare("UPDATE productos SET 
                Nombre = ?, Precio = ?, Stock = ?, Descripcion = ?, Estado = ?, IDCategoria = ?
                WHERE IDProducto = ? AND IDUsuario = ?");
            $stmt->execute([$nombre, $precio, $cantidad, $descripcion, $estado, $categoria, $productoID, $id_usuario]);
        } else {
            $stmt = $pdo->prepare("INSERT INTO productos 
                (Nombre, Precio, Stock, Descripcion, Estado, IDUsuario, IDCategoria) 
                VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$nombre, $precio, $cantidad, $descripcion, $estado, $id_usuario, $categoria]);
            $productoID = $pdo->lastInsertId(); // importante para poder insertar multimedia
        }


        // Insertar multimedia
        if (!empty($multimedia)) {
            try {
                $stmtMedia = $pdo->prepare("INSERT INTO multimediaPublicacion (IDProducto, path, IDUsuario) VALUES (?, ?, ?)");
                foreach ($multimedia as $archivo) {
                    $stmtMedia->execute([$productoID, $archivo, $id_usuario]);
                }
            } catch (PDOException $e) {
                throw new Exception("Error al insertar multimedia: " . $e->getMessage());
            }

        }


        ob_clean(); // Limpiar cualquier salida previa
        echo json_encode([
            'success' => true,
            'message' => 'Producto registrado exitosamente.',
            'product_id' => $productoID,
            'multimedia' => $multimedia
        ]);
    } catch (Exception $e) {
        http_response_code(400);
        ob_clean();
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}

// Manejo para GET: Obtener productos
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $stmt = $pdo->query("SELECT * FROM productos WHERE Estado = 0");
        $productos = $stmt->fetchAll(PDO::FETCH_ASSOC);

        ob_clean();
        echo json_encode(['success' => true, 'data' => $productos]);
    } catch (PDOException $e) {
        http_response_code(500);
        ob_clean();
        echo json_encode(['success' => false, 'message' => 'Error al obtener productos.']);
    }
    exit;
}

// Si no es GET ni POST
http_response_code(405);
ob_clean();
echo json_encode(['success' => false, 'message' => 'Método no permitido.']);
exit;

?>